(function() {
	"use strict";

	angular.module("myApp",['ui.bootstrap']);

})();